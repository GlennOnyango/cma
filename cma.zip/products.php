<?php 
$products= array(
"product1"=> array(
"title" => "My amazing product1",
"price"=> 6700,
"features" => array("feature 1","feature 2","feature 3")
),
"product2"=> array(
"title" => "My amazing product2",
"price"=> 14700,
"features" => array("feature 1","feature 2","feature 3")
),
"product3"=> array(
"title" => "My amazing product3",
"price"=> 6700,
"features" => array("feature 1","feature 2","feature 3")
),

);

?>
(function($) {
    "use strict";

    $('#inboxTable').tablesorter({
        headers: { 
            0: {
                sorter: false 
            },
            1: {
                sorter: false 
            },
            4: {
                sorter: false 
            }
        }
    });

})(jQuery);
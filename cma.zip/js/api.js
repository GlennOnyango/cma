function fetchData(){
	console.log("start fetch");
}

fetchData();
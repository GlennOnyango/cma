var reg_form = document.querySelector("#myreg_form");
var log_form = document.querySelector("#log_form");
var for_form = document.querySelector("#for_form");
var url = "http://localhost/cma/controller/authG.php";


const path = window.location.origin;

reg_form.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(reg_form);

    
    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: url,
        data: formData,
        crossDomain: true,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function(data) {
            console.log(data);
            // alert(data);
            const obj = JSON.parse(data);
              if (obj.result = "success") 
            {
            sessionStorage.setItem("loggedIn", obj["value"]);
     
            if(obj.role="admin"){
           window.location.replace(`${path}/cma/admin`);
            }else if(obj.role="advocate"){
               window.location.replace(`${path}/cma/advocate`);
            }else if(obj.role="user"){
                   window.location.replace(`${path}/cma/profile.html`);
            }
            }

        },
        error: function(e) {

            console.log(data);

        },
        done: function(e) {

            console.log("Done :", e);
        }

    });

    console.log("done");
});

log_form.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(log_form);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: url,
        data: formData,
        crossDomain: true,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function(data) {

            console.log(data);
            const obj = JSON.parse(data);
              if (obj.result = "logged") 
            {
            sessionStorage.setItem("loggedIn", obj["value"]);

            }else{
            }

        },
        error: function(e) {

            console.log(data);

        },
        done: function(e) {

            console.log("Done :", e);
        }

    });

 

});

for_form.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(for_form);

    $.ajax({
        type: "POST",
        enctype: 'multipart/form-data',
        url: url,
        data: formData,
        crossDomain: true,
        processData: false,
        contentType: false,
        cache: false,
        timeout: 600000,
        success: function(data) {

            console.log(data);
            const obj = JSON.parse(data);
            console.log(obj.value);
        },
        error: function(e) {

            console.log(data);

        },
        done: function(e) {

            console.log("Done :", e);
        }

    });

 

});

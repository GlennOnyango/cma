-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 19, 2021 at 03:48 PM
-- Server version: 5.7.31
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cma`
--

-- --------------------------------------------------------

--
-- Table structure for table `lawyers`
--

DROP TABLE IF EXISTS `lawyers`;
CREATE TABLE IF NOT EXISTS `lawyers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) NOT NULL,
  `email` int(11) NOT NULL,
  `type` enum('Associate','Senior associate') DEFAULT 'Associate',
  `practiseArea` varchar(255) NOT NULL,
  `availabilityDays` blob,
  `availabilityFrom` time DEFAULT NULL,
  `availabilityTo` time DEFAULT NULL,
  `quarterCharge` int(11) DEFAULT NULL,
  `halfCharge` int(11) DEFAULT NULL,
  `threeQuarterCharge` int(11) DEFAULT NULL,
  `hourCharge` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_sessions`
--

DROP TABLE IF EXISTS `login_sessions`;
CREATE TABLE IF NOT EXISTS `login_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `sessionId` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `ipAddress` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateExpires` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_sessions`
--

INSERT INTO `login_sessions` (`id`, `userId`, `sessionId`, `active`, `ipAddress`, `dateCreated`, `dateExpires`) VALUES
(1, 2, 'lglWFp6gSI4HOyu', 1, '::1', '2021-09-18 14:56:35', '2021-09-19 11:56:35'),
(2, 2, 'hscIREHSELy4Mco', 1, '::1', '2021-09-18 14:57:02', '2021-09-19 11:57:02'),
(3, 2, 'q6deusSMIWr3ogL', 1, '::1', '2021-09-18 14:57:31', '2021-09-19 11:57:31'),
(4, 2, 'hcgrI4Oo0P1xWbL', 1, '::1', '2021-09-18 14:58:58', '2021-09-19 11:58:58'),
(5, 2, 'af2SeMys8Pt7Rqf', 1, '::1', '2021-09-18 22:13:58', '2021-09-19 19:13:58'),
(6, 2, 'rz5ya4U0i9cWQwt', 1, '::1', '2021-09-19 18:21:53', '2021-09-20 15:21:53'),
(7, 2, 'T3Qvxnq4599Wnua', 1, '::1', '2021-09-19 18:28:50', '2021-09-20 15:28:50'),
(8, 4, 'YKab9PwDe690b3T', 1, '::1', '2021-09-19 18:39:39', '2021-09-20 15:39:39'),
(9, 7, 'sC7MkXX8wXHVPyO', 1, '::1', '2021-09-19 18:43:58', '2021-09-20 15:43:58');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`, `dateCreated`, `dateUpdated`) VALUES
(1, 'admin', '2021-08-25 18:28:08', '2021-08-25 18:28:08'),
(2, 'secretary', '2021-08-25 18:28:08', '2021-08-25 18:28:08'),
(3, 'speaker', '2021-08-25 18:28:54', '2021-08-25 18:28:54'),
(4, 'staff', '2021-08-25 18:28:54', '2021-08-25 18:28:54');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roleId` int(11) DEFAULT '1',
  `firstName` varchar(255) NOT NULL,
  `idNumber` int(10) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `businessName` varchar(255) NOT NULL,
  `registrationNumber` varchar(255) NOT NULL,
  `physicalAddress` varchar(255) NOT NULL,
  `phoneNumber` varchar(255) NOT NULL,
  `subscribeToNewsletter` varchar(11) NOT NULL DEFAULT '0',
  `agreeToTerms` varchar(11) NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL,
  `contactFirstName` varchar(255) DEFAULT NULL,
  `contactLastName` varchar(255) DEFAULT NULL,
  `contactPhoneNumber` varchar(255) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateUpdated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `roleId`, `firstName`, `idNumber`, `email`, `businessName`, `registrationNumber`, `physicalAddress`, `phoneNumber`, `subscribeToNewsletter`, `agreeToTerms`, `password`, `contactFirstName`, `contactLastName`, `contactPhoneNumber`, `active`, `dateCreated`, `dateUpdated`) VALUES
(2, 1, 'Oscar', NULL, 'oscarkipkoech@gmail.com', 'Heinosoft', '987654', 'kj', '711522738', '', '0', '$2y$10$xu6LVmhNMMrPQIfw738ZaOxIYRXg49HtP8GR2.7p5fXD0Qp/T9MFi', 'Oscar', 'Bett', '07121221288', 1, '2021-09-18 14:45:05', '2021-09-18 14:45:05'),
(7, 1, 'Ethan', NULL, 'ethanchege@gmail.com', 'Heinosoft', '123423', 'test', '32710000000', '', '0', '$2y$10$VMKCzHDulQclpoX80Sl74uhfy9oO/5/J5QxpWIY.lOYACoh8uw8Cq', NULL, NULL, NULL, 0, '2021-09-19 18:43:45', '2021-09-19 18:43:45');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
